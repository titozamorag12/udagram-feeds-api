"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const FeedItem_1 = require("./feed/models/FeedItem");
exports.V0_FEED_MODELS = [FeedItem_1.FeedItem];
//# sourceMappingURL=model.index.js.map